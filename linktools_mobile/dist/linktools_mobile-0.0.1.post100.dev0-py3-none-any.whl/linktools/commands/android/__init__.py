__command__ = "at"
__description__ = "Android scripts"
__order__ = "\x1f200-android"
