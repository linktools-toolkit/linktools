#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import errno
import io
import os
import queue
import subprocess
import threading
import time as _time
from collections import ChainMap
from typing import TYPE_CHECKING

from ..decorator import cached_property, timeoutable
from ..errors import ExecError
from ..system import is_unix_like, wait_process
from ..utils import list2cmdline

if TYPE_CHECKING:
    from collections.abc import Generator
    from typing import Any, AnyStr, Callable, IO
    from ..types import PathType, Timeout, TimeoutType

STDOUT = 1
STDERR = 2


def _coalesce(*args):
    for arg in args:
        if arg is not None:
            return arg
    return None


def _get_environ():
    from ..core import environ
    return environ


_logger = None


def _get_logger():
    global _logger
    if _logger is None:
        _logger = _get_environ().get_logger("process")
    return _logger


def _subprocess_env() -> "dict[str, str]":
    """Build the base environment every subprocess spawned via ``popen``
    starts from: ``os.environ``, overlaid with the current project's
    profile-declared ``"env"`` section (``.linktools.json`` /
    ``linktools.json``), then with the managed-tools stub dir prepended
    to PATH so tools resolve without a global PATH mutation.

    Returns a fresh mapping; never mutates the process ``os.environ``.
    """
    environ = _get_environ()
    env = dict(os.environ)
    profile_env = environ.profile.get("env", {})
    if profile_env:
        env.update({str(key): str(value) for key, value in profile_env.items()})
    try:
        stub = str(environ.tools.stub_path)
        if stub:
            rest = [p for p in env.get("PATH", "").split(os.pathsep)
                    if p and p != stub]
            env["PATH"] = os.pathsep.join([stub] + rest)
    except Exception:
        pass
    return env


if is_unix_like():

    class Output:

        def __init__(self, stdout: "IO[AnyStr]", stderr: "IO[AnyStr]"):
            self._stdout = stdout
            self._stderr = stderr

        def get(self, timeout: "Timeout") -> "Generator[tuple[int, AnyStr], Any, Any]":
            import select

            fds = []
            stdout, stderr = None, None
            if self._stdout:
                stdout = self.IOWrapper(self._stdout, STDOUT)
                fds.append(stdout.fd)
            if self._stderr:
                stderr = self.IOWrapper(self._stderr, STDERR)
                fds.append(stderr.fd)

            while len(fds) > 0:
                remain = _coalesce(timeout.remaining, 1)
                if remain <= 0:
                    break
                rlist, wlist, xlist = select.select(fds, [], [], min(remain, 1))
                if stdout.fd is not None and stdout.fd in rlist:
                    yield from stdout.read_lines()
                    if stdout.closed:
                        fds.remove(stdout.fd)
                if stderr.fd is not None and stderr.fd in rlist:
                    yield from stderr.read_lines()
                    if stderr.closed:
                        fds.remove(stderr.fd)

            yield from stdout.read_remain_line()
            yield from stderr.read_remain_line()

        class IOWrapper:

            def __init__(self, io: "IO[AnyStr]", code: int):
                self.io = io
                self.fd = io.fileno()
                self.code = code
                self.closed = False
                self.buffer = bytearray()

            def read_lines(self) -> "Generator[tuple[int, AnyStr], Any, Any]":
                data = None
                try:
                    if not self.closed:
                        data = os.read(self.fd, 32768)
                        if data:
                            self.buffer.extend(data)
                except OSError as e:
                    if e.errno != errno.EBADF:
                        _get_logger().debug(f"Read io error: {e}")
                if data:
                    while True:
                        index = self.buffer.find(b"\n")
                        if index < 0:
                            break
                        self.buffer, line = self.buffer[index + 1:], self.buffer[:index + 1]
                        line = line.decode(self.io.encoding, self.io.errors) \
                            if isinstance(self.io, io.TextIOWrapper) \
                            else bytes(line)
                        yield self.code, line
                else:
                    yield from self.read_remain_line()
                    self.closed = True

            def read_remain_line(self) -> "Generator[tuple[int, AnyStr], Any, Any]":
                if self.buffer:
                    self.buffer, line = bytearray(), self.buffer
                    line = line.decode(self.io.encoding, self.io.errors) \
                        if isinstance(self.io, io.TextIOWrapper) \
                        else bytes(line)
                    yield self.code, line


else:

    class Output:

        def __init__(self, stdout: "IO[AnyStr]", stderr: "IO[AnyStr]"):
            self._queue = queue.Queue()
            self._stdout_finished = None
            self._stdout_thread = None
            self._stderr_finished = None
            self._stderr_thread = None
            if stdout:
                self._stdout_finished = threading.Event()
                self._stdout_thread = threading.Thread(
                    target=self._iter_lines,
                    args=(stdout, STDOUT, self._stdout_finished,)
                )
                self._stdout_thread.daemon = True
                self._stdout_thread.start()
            if stderr:
                self._stderr_finished = threading.Event()
                self._stderr_thread = threading.Thread(
                    target=self._iter_lines,
                    args=(stderr, STDERR, self._stderr_finished,)
                )
                self._stderr_thread.daemon = True
                self._stderr_thread.start()

        @property
        def is_alive(self) -> bool:
            if self._stdout_finished and not self._stdout_finished.is_set():
                return True
            if self._stderr_finished and not self._stderr_finished.is_set():
                return True
            return False

        def _iter_lines(self, io: "IO[AnyStr]", code: int, event: "threading.Event"):
            try:
                while True:
                    data = io.readline()
                    if not data:
                        break
                    self._queue.put((code, data))
            except OSError as e:
                if e.errno != errno.EBADF:
                    _get_logger().debug(f"Handle output error: {e}")
            finally:
                event.set()
                self._queue.put((None, None))

        def get(self, timeout: "Timeout") -> "Generator[tuple[int, AnyStr], Any, Any]":
            while self.is_alive:
                remain = _coalesce(timeout.remaining, 1)
                if remain <= 0:
                    break
                try:
                    code, data = self._queue.get(timeout=min(remain, 1))
                    if code is not None:
                        yield code, data
                except queue.Empty:
                    pass

            while True:
                try:
                    code, data = self._queue.get_nowait()
                    if code is not None:
                        yield code, data
                except queue.Empty:
                    break


class ProcessResult(object):
    """Result of a completed process ."""

    def __init__(self, args: "Any", returncode: int, stdout: "Any" = None,
                 stderr: "Any" = None, duration: "float | None" = None,
                 timed_out: bool = False) -> None:
        self.args = args
        self.returncode = returncode
        self.stdout = stdout
        self.stderr = stderr
        self.duration = duration
        self.timed_out = timed_out

    @property
    def succeeded(self) -> bool:
        return self.returncode == 0

    def __repr__(self):
        return "ProcessResult(args=%r, returncode=%d, duration=%.2fs)" % (
            self.args, self.returncode, self.duration or 0)


class Process(object):
    """Composition wrapper around subprocess.Popen.

    Delegates supported Popen attributes (wait, poll, kill, stdout, pid,
    returncode, ...) via __getattr__ so they work unchanged, while owning its
    own lifecycle methods (call, check_call, fetch, exec, recursive_kill,
    wait_for_result).
    """

    def __init__(self, *args: "Any", **kwargs: "Any") -> None:
        self._popen = subprocess.Popen(*args, **kwargs)
        self._started_at = _time.monotonic()

    def __getattr__(self, name):
        # Delegate any attribute not defined on Process to the wrapped Popen.
        # This covers wait, poll, kill, terminate, communicate, stdout, stderr,
        # stdin, pid, returncode, args, etc.
        return getattr(self._popen, name)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self._popen.wait()
        self.close()

    def close(self) -> None:
        """Explicitly close this process's stdin/stdout/stderr pipes.

        ``subprocess.Popen`` otherwise relies on ``__del__`` (CPython
        reference-counting, but not guaranteed prompt -- a cached_property
        or another lingering reference can defer it) to release these pipe
        file descriptors. Fine for one ad-hoc subprocess; anything that
        runs many short-lived subprocesses within one long-lived process
        (the test suite, in particular) can accumulate enough GC-deferred
        pipe FDs to exceed ``select()``'s ``FD_SETSIZE`` limit. Every
        completion path (``__exit__``, ``exec()``,
        ``StructuredCommandRunner.execute()``) closes explicitly instead of
        waiting on GC. Idempotent and safe to call more than once.
        """
        for stream in (self._popen.stdin, self._popen.stdout, self._popen.stderr):
            if stream is not None and not stream.closed:
                try:
                    stream.close()
                except OSError:
                    pass

    @classmethod
    def start(cls, *args: "Any", **kwargs: "Any") -> "Process":
        """Create and start a Process ."""
        return cls(*args, **kwargs)

    def wait_for_result(self, timeout: "TimeoutType | None" = None) -> "ProcessResult":
        """Wait for the process and return a ProcessResult ."""
        from ..types import Timeout
        timed_out = False
        wall = None
        if timeout is not None:
            t = Timeout(timeout)
            wall = t.remaining
        try:
            retcode = self._popen.wait(timeout=wall)
        except subprocess.TimeoutExpired:
            self.recursive_kill()
            retcode = self._popen.returncode
            timed_out = True
        duration = _time.monotonic() - self._started_at
        return ProcessResult(
            args=self._popen.args,
            returncode=retcode,
            stdout=self._popen.stdout,
            stderr=self._popen.stderr,
            duration=duration,
            timed_out=timed_out,
        )

    @timeoutable
    def call(self, timeout: "TimeoutType | None" = None) -> int:
        with self:
            try:
                return self._popen.wait(timeout.remaining)
            except Exception:
                self.recursive_kill()
                raise

    @timeoutable
    def check_call(self, timeout: "TimeoutType | None" = None) -> int:
        with self:
            try:
                retcode = self._popen.wait(timeout.remaining)
                if retcode:
                    raise subprocess.CalledProcessError(retcode, self._popen.args)
                return retcode
            except Exception:
                self.recursive_kill()
                raise

    @timeoutable
    def fetch(self, timeout: "TimeoutType | None" = None) -> "Generator[tuple[AnyStr | None, AnyStr | None], Any, Any]":
        if self.stdout or self.stderr:
            for code, data in self._output.get(timeout):
                out = err = None
                if code == STDOUT:
                    out = data
                elif code == STDERR:
                    err = data
                yield out, err
        wait_process(self, timeout)

    @timeoutable
    def exec(
            self,
            timeout: "TimeoutType | None" = None,
            ignore_errors: bool = False,
            on_stdout: "Callable[[str], None] | None" = None,
            on_stderr: "Callable[[str], None] | None" = None,
            error_type: "Callable[[str], Exception]" = ExecError
    ) -> str:
        try:
            out = err = None
            for _out, _err in self.fetch(timeout=timeout):
                if _out is not None:
                    out = _out if out is None else out + _out
                    if on_stdout:
                        data: str = _out.decode(errors="ignore") if isinstance(_out, bytes) else _out
                        data = data.rstrip()
                        if data:
                            on_stdout(data)
                if _err is not None:
                    err = _err if err is None else err + _err
                    if on_stderr:
                        data: str = _err.decode(errors="ignore") if isinstance(_err, bytes) else _err
                        data = data.rstrip()
                        if data:
                            on_stderr(data)

            if not ignore_errors and self.poll() not in (0, None):
                if isinstance(err, bytes):
                    err = err.decode(errors="ignore")
                    err = err.strip()
                elif isinstance(err, str):
                    err = err.strip()
                if err:
                    raise error_type(err)

            if isinstance(out, bytes):
                out = out.decode(errors="ignore")
                out = out.strip()
            elif isinstance(out, str):
                out = out.strip()

            return out or ""

        finally:
            self.recursive_kill()
            self.close()

    def recursive_kill(self) -> None:
        import psutil
        try:
            for p in reversed(psutil.Process(self.pid).children(recursive=True)):
                try:
                    p.terminate()
                except psutil.NoSuchProcess:
                    pass
                except Exception as e:
                    _get_logger().debug(f"Kill children process failed: {e}")
        except psutil.NoSuchProcess:
            pass
        except Exception as e:
            _get_logger().debug(f"List children process failed: {e}")

        self.terminate()
        try:
            # Reap this process before returning -- terminate() only sends
            # the signal, it never waits. Without this, a process this call
            # terminates (e.g. after a fetch() timeout, which never reaches
            # its own wait_process()) stays an unreaped zombie with
            # returncode still None, and Popen.__del__ later emits
            # "ResourceWarning: subprocess N is still running" when this
            # Process is garbage collected.
            self._popen.wait(timeout=5)
        except subprocess.TimeoutExpired:
            try:
                self._popen.kill()
                self._popen.wait(timeout=5)
            except subprocess.TimeoutExpired:
                _get_logger().debug(f"Process {self.pid} did not exit after kill")

    @cached_property(lock=True)
    def _output(self):
        return Output(self.stdout, self.stderr)


def popen(
        *args: "Any",
        capture_output: bool = False,
        stdin: "int | IO | None" = None, stdout: "int | IO | None" = None, stderr: "int | IO | None" = None,
        shell: bool = False, cwd: "PathType | None" = None,
        env: "dict[str, str] | None" = None, append_env: "dict[str, str] | None" = None, default_env: "dict[str, str] | None" = None,
        **kwargs: "Any"
) -> "Process":
    args = [str(arg) for arg in args]

    if capture_output is True:
        if stdout is not None or stderr is not None:
            raise ValueError("stdout and stderr arguments may not be used "
                             "with capture_output.")
        stdout = subprocess.PIPE
        stderr = subprocess.PIPE

    if not cwd:
        try:
            cwd = os.getcwd()
        except FileNotFoundError:
            cwd = _get_environ().temp_path
            cwd.mkdir(parents=True, exist_ok=True)

    # Every subprocess spawned here gets the same base environment (not
    # just ones a tool-execution call site remembers to build itself):
    # os.environ, this project's own profile-declared "env"
    # overlay, and the managed-tools stub prepended to PATH. An explicit
    # ``env=`` fully replaces this base, same as before.
    base_env = env if env is not None else _subprocess_env()
    if append_env or default_env:
        maps = []
        if append_env is not None:
            maps.append(append_env)
        maps.append(base_env)
        if default_env is not None:
            maps.append(default_env)
        env = ChainMap(*maps)
    else:
        env = base_env

    _get_logger().debug(f"Exec cmdline: {list2cmdline(args)}")

    return Process(
        args,
        stdin=stdin, stdout=stdout, stderr=stderr,
        shell=shell, cwd=cwd,
        env=env,
        **kwargs
    )
