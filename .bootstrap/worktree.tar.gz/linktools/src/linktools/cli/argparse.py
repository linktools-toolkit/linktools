#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import abc
import argparse
import os
import typing

from .. import utils
from ..decorator import cached_classproperty
from ..types import MISSING

if typing.TYPE_CHECKING:
    from collections.abc import Callable, Iterable
    from typing import Any

    from ..core import ConfigField
    from ._command import CommandParser


##############################
# argparse types
##############################


def range_type(min: int, max: int) -> "Callable[[str], int]":
    """Create an argparse converter that accepts integers in a range.

    Args:
        min (int): The min value.
        max (int): The max value.

    Returns:
        Any: The operation result.

    Raises:
        Exception: Propagates errors raised while completing the operation.
    """

    def wrapper(o: str) -> int:
        value = utils.int(o)
        if min <= value <= max:
            return value
        raise ValueError("value not in range %s-%s" % (min, max))

    return wrapper


class LazyChoices(typing.Iterable):
    """Lazy iterable wrapper for argparse choices."""

    def __init__(
        self,
        func: "Callable[..., Iterable[Any]]",
        *args: "Any",
        **kwargs: "Any",
    ):
        self._data = MISSING
        self._fn = func
        self._args = args
        self._kwargs = kwargs

    def _load(self):
        result = self._data
        if result == MISSING:
            result = self._data = self._fn(*self._args, **self._kwargs)
        return result

    def __iter__(self):
        return iter(self._load())

    def __contains__(self, item):
        if item == argparse.SUPPRESS:
            return True
        if isinstance(item, (list, tuple)) and len(item) == 0:
            return True
        return self._load().__contains__(item)


##############################
# argparse actions
##############################


class ConfigLoader:
    """Load configuration-backed argparse values after parsing."""

    def __call__(
        self, parser: "CommandParser", action: "ConfigAction", namespace, value=MISSING
    ):

        from ._command import CommandParser

        if not isinstance(parser, CommandParser) or not parser.command:
            raise argparse.ArgumentError(
                action, "ConfigAction only support CommandParser"
            )

        config = parser.command.config
        field = getattr(action, "property", None)
        if value is MISSING or isinstance(value, ConfigLoader):
            # No CLI value — resolve via config (env → cache → prompt).
            key = field if field is not None else action.dest
            value = config.get(key, type=action.type, default=MISSING)
        # CLI values are one-shot: they do NOT overwrite the cache.
        # Secret values are never persisted regardless of source.
        setattr(namespace, action.dest, value)


class ConfigAction(argparse.Action):
    """Argparse action that binds an option to a configuration field."""

    def __init__(
        self,
        option_strings: "list[str]",
        dest: str,
        default: "Any" = MISSING,
        type: "Callable[[str], Any] | type | None" = None,
        choices: "Iterable[Any] | None" = None,
        required: bool = False,
        help: "str | None" = None,
        metavar: "str | tuple[str, ...] | None" = None,
        nargs: "int | str | None" = None,
        config: "ConfigField | None" = None,
    ) -> None:
        super().__init__(
            option_strings=option_strings,
            dest=dest,
            nargs=nargs,
            const=None,
            default=ConfigLoader(),
            type=type,
            choices=choices,
            required=required,
            help=help,
            metavar=metavar,
        )

        from ..core import ConfigField

        if not isinstance(config, ConfigField):
            raise argparse.ArgumentError(self, "config must be ConfigField")

        self.property = config
        if default is not MISSING:
            if config.default is MISSING or config.default is None:
                config.default = default

    def __call__(self, parser: "CommandParser", namespace, values, option_string=None):
        if not ArgParseComplete.is_invocation():
            loader = self.default
            if isinstance(loader, ConfigLoader):
                loader(parser, self, namespace, values)


if not hasattr(argparse, "BooleanOptionalAction"):

    class BooleanOptionalAction(argparse.Action):
        def __init__(
            self,
            option_strings: "list[str]",
            dest: str,
            default: "Any" = None,
            type: "Callable[[str], Any] | type | None" = None,
            choices: "Iterable[Any] | None" = None,
            required: bool = False,
            help: "str | None" = None,
            metavar: "str | tuple[str, ...] | None" = None,
        ) -> None:

            _option_strings = []
            for option_string in option_strings:
                _option_strings.append(option_string)

                if option_string.startswith("--"):
                    option_string = "--no-" + option_string[2:]
                    _option_strings.append(option_string)

            super().__init__(
                option_strings=_option_strings,
                dest=dest,
                nargs=0,
                default=default,
                type=type,
                choices=choices,
                required=required,
                help=help,
                metavar=metavar,
            )

        def __call__(self, parser, namespace, values, option_string=None):
            if option_string in self.option_strings:
                setattr(namespace, self.dest, not option_string.startswith("--no-"))

        def format_usage(self) -> str:
            return " | ".join(self.option_strings)

else:
    BooleanOptionalAction = argparse.BooleanOptionalAction


class KeyValueAction(argparse.Action):
    """Argparse action that collects KEY=VALUE pairs into a dict."""

    def __init__(
        self,
        option_strings: "list[str]",
        dest: str,
        nargs: "int | str | None" = None,
        default: "Any" = None,
        required: bool = False,
        help: "str | None" = None,
        metavar: str = "KEY=VALUE",
    ) -> None:

        super().__init__(
            option_strings=option_strings,
            dest=dest,
            nargs=nargs,
            default=default,
            # type=dict,
            required=required,
            help=help,
            metavar=metavar,
        )

    def __call__(self, parser, namespace, value, option_string=None):
        dest = getattr(namespace, self.dest) or {}

        if value:
            if isinstance(value, str):
                value = [value]
            for item in value:
                kv = item.split("=", 1)
                k = kv[0]
                v = kv[1] if len(kv) >= 2 else ""
                if not isinstance(dest, dict):
                    try:
                        setattr(dest, k, v)
                    except Exception as e:
                        raise argparse.ArgumentError(self, str(e))
                else:
                    dest[k] = v

        setattr(namespace, self.dest, dest)


##############################
# auto complete
##############################


class ArgParseComplete:
    """Helpers for argcomplete integration and completion detection."""

    @cached_classproperty
    def _argcomplete(self):
        try:
            import argcomplete

            return argcomplete
        except ModuleNotFoundError:
            return None

    @classmethod
    def is_invocation(cls) -> bool:
        """Return whether the current process is an argcomplete invocation.

        Returns:
            Any: The operation result.
        """
        return "_ARGCOMPLETE" in os.environ  # and cls._argcomplete

    @classmethod
    def autocomplete(
        cls, argument_parser: "argparse.ArgumentParser", **kwargs: "Any"
    ) -> "argparse.ArgumentParser":
        """Enable argcomplete for an argument parser when available.

        Args:
            argument_parser (argparse.ArgumentParser): The argument_parser value.
            kwargs: Keyword arguments passed to the operation.

        Returns:
            argparse.ArgumentParser: The operation result.
        """
        argcomplete = cls._argcomplete
        if argcomplete:
            argcomplete.autocomplete(argument_parser, **kwargs)
        return argument_parser

    @classmethod
    def shellcode(
        cls, executables: "typing.Iterable[str]", shell: str, **kwargs: "Any"
    ) -> str:
        """Return shell completion setup code when argcomplete is available.

        Args:
            executables (typing.Iterable[str]): The executables value.
            shell (str): The shell value.
            kwargs: Keyword arguments passed to the operation.

        Returns:
            str: The operation result.
        """
        argcomplete = cls._argcomplete
        if argcomplete:
            return argcomplete.shellcode(executables, shell=shell, **kwargs)
        return ""

    class Completer(abc.ABC):
        @abc.abstractmethod
        def get_parser(self) -> "argparse.ArgumentParser":
            pass

        @abc.abstractmethod
        def get_args(
            self, parsed_args: "argparse.Namespace", **kwargs: "Any"
        ) -> "list[str] | None":
            pass

        def __call__(self, *, parsed_args, **kwargs):
            completions = {}

            args = self.get_args(parsed_args, **kwargs)
            if args is None:
                return completions

            argcomplete = ArgParseComplete._argcomplete
            if not argcomplete:
                return completions

            finder = argcomplete.CompletionFinder(self.get_parser())
            cmdline = f"{utils.list2cmdline(args)} "

            state = 0
            while True:
                item = finder.rl_complete(cmdline, state)
                if item is None:
                    break
                key = item[len(cmdline) :]
                completions[key] = finder.get_display_completions().get(key, "")
                state += 1

            return completions
