#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import abc
import functools
import inspect
import logging
import os
import sys
import textwrap
import traceback
from argparse import ArgumentParser, Action, Namespace
from argparse import RawDescriptionHelpFormatter, SUPPRESS
from pkgutil import walk_packages
from types import ModuleType, GeneratorType
from typing import TYPE_CHECKING

from .argparse import BooleanOptionalAction, ArgParseComplete, ConfigAction, ConfigLoader
from ..core import environ, BaseCapability, ConfigField
from ..decorator import cached_property
from ..types import MISSING
from ..rich import is_rich_available
from ..errors import CliError, ConfigCastError
from ..runtime import import_module

if TYPE_CHECKING:
    from argparse import FileType, HelpFormatter
    from collections.abc import Callable, Generator, Iterable
    from typing import Any, Literal
    from rich.tree import Tree
    from ..core import BaseEnviron
    from ..types import T

    ERROR_HANDLER = Literal["error", "ignore", "warn"] | Callable[[str, Exception], None]


def _debug_enabled(target: "BaseEnviron") -> bool:
    """Return debug state without allowing an invalid external value to abort CLI handling."""
    try:
        return target.debug
    except ConfigCastError:
        return False


class CommandError(CliError):
    """Base exception for command-line failures.

    The CLI exit-code mapper treats command/user-input errors as exit 2
    rather than internal (10).
    """
    pass


class SubCommandError(CommandError):
    """Raised when subcommand discovery or execution fails."""
    pass


class NotFoundSubCommand(SubCommandError):
    """Raised when no runnable subcommand can be resolved."""
    pass


class CommandParser(ArgumentParser):

    """ArgumentParser subclass that applies deferred config actions."""
    def __init__(self, *args: "Any", command: "BaseCommand" = None, **kwargs: "Any") -> None:
        super().__init__(*args, **kwargs)
        self._command = command

    @property
    def command(self) -> "BaseCommand":
        """Command.

        Returns:
            BaseCommand: The property value.
        """
        return self._command

    def parse_known_args(self, args: "list[str] | None" = None, namespace: "Namespace | None" = None) -> "tuple[Namespace, list[str]]":
        """Parse args and resolve deferred config actions.

        Args:
            args: Arguments passed to the operation.
            namespace: Argparse namespace to update.

        Returns:
            Any: The operation result.
        """
        namespace, args = super().parse_known_args(args, namespace)
        for action in self._actions:
            if isinstance(action, ConfigAction):
                value = getattr(namespace, action.dest, None)
                if isinstance(value, ConfigLoader):
                    value(parser=self, action=action, namespace=namespace)
        return namespace, args


class _CommandInfo:
    id: str
    parent_id: str
    module: str
    command: "BaseCommand | None"
    command_name: str
    command_description: str
    order: str
    declared_parent_group: "CommandGroupRef | None" = None


def _iter_entry_points(group: str, *, onerror: "ERROR_HANDLER" = "error"):
    from ..core import select_entry_points

    eps = select_entry_points(group)
    for ep in eps:
        try:
            yield ep, ep.load()
        except Exception as e:
            if callable(onerror):
                onerror(ep.name, e)
            elif onerror == "error":
                raise e
            elif onerror == "warn":
                environ.logger.warning(
                    f"Ignore {ep.name}, caused by {e.__class__.__name__}: {e}",
                    exc_info=True if _debug_enabled(environ) else None
                )
            elif onerror == "ignore":
                pass


def iter_module_commands(root: "ModuleType", *, onerror: "ERROR_HANDLER" = "error") -> "Generator[_CommandInfo, Any, Any]":
    """Yield command descriptors discovered from a command module package.

    Args:
        root (ModuleType): The root value.
        onerror (ERROR_HANDLER): The onerror value.

    Returns:
        Generator[_CommandInfo, Any, Any]: The operation result.

    Raises:
        Exception: Propagates errors raised while completing the operation.
    """
    prefix = root.__name__ + "."
    for finder, name, is_package in walk_packages(path=root.__path__, prefix=prefix):
        try:
            module = import_module(name, spec=finder.find_spec(name))
            info = _CommandInfo()
            # A package or module that exposes a `command` attribute (a BaseCommand
            # instance) is discovered as a command node directly. This lets a
            # sub-package act as a single command (e.g. `lt ai <subcommand>`) when
            # its `__init__.py` re-exports `command`, matching the cntr pattern.
            if hasattr(module, "command") and isinstance(module.command, BaseCommand):
                command = module.command
                parent = command.parent
                if not parent:
                    # Preserve the existing module-path-derived fallback so a
                    # command with no explicit parent still nests correctly.
                    parent = name[len(prefix):name.rfind(".")]
                info.id = name[len(prefix):]
                info.parent_id, info.declared_parent_group = _normalize_parent(parent)
                info.module = name
                info.command = command
                info.command_name = command.name
                info.command_description = command.description
                info.order = command.order
                yield info
            elif is_package:
                info.id = name[len(prefix):]
                info.parent_id = getattr(module, "__parent__", None) or name[len(prefix):name.rfind(".")]
                info.module = module.__name__
                info.command = None
                info.command_name = getattr(module, "__command__", None) or info.id[info.id.rfind(".") + 1:]
                info.command_description = getattr(module, "__description__", None) or ""
                info.order = getattr(module, "__order__", None) or info.command_name
                yield info
        except Exception as e:
            if callable(onerror):
                onerror(name, e)
            elif onerror == "error":
                raise e
            elif onerror == "warn":
                environ.logger.warning(
                    f"Ignore {name}, caused by {e.__class__.__name__}: {e}",
                    exc_info=True if _debug_enabled(environ) else None
                )
            elif onerror == "ignore":
                pass


def iter_entry_point_commands(group: str, *, onerror: "ERROR_HANDLER" = "error") -> "Generator[_CommandInfo, Any, Any]":
    """Yield command descriptors discovered from entry points.

    Args:
        group (str): The group value.
        onerror (ERROR_HANDLER): The onerror value.

    Returns:
        Generator[_CommandInfo, Any, Any]: The operation result.
    """
    for ep, obj in _iter_entry_points(group, onerror=onerror):
        if isinstance(obj, CommandMain):
            command = obj.command
            parent_id, declared_parent_group = _normalize_parent(command.parent)
            info = _CommandInfo()
            info.id = _join_id(parent_id, command.name)
            info.parent_id = parent_id
            info.declared_parent_group = declared_parent_group
            info.module = ep.module
            info.command = command
            info.command_name = command.name
            info.command_description = command.description
            info.order = command.order
            yield info
        elif isinstance(obj, ModuleType):
            yield from iter_module_commands(obj, onerror=onerror)


def iter_entry_points_capabilities(group: str, *, onerror: "ERROR_HANDLER" = "error") -> "Generator[BaseCapability, Any, Any]":
    """Yield capability objects discovered from entry points.

    Args:
        group (str): The group value.
        onerror (ERROR_HANDLER): The onerror value.

    Returns:
        Iterator[Any]: Generated values.
    """
    for _, obj in _iter_entry_points(group, onerror=onerror):
        if isinstance(obj, BaseCapability):
            yield obj
        elif inspect.isclass(obj) and issubclass(obj, BaseCapability):
            yield obj()


def _filter_kwargs(kwargs):
    return {k: v for k, v in kwargs.items() if v is not MISSING}


class _SubCommandActionInfo:

    def __init__(self, action: "Action", no_param: bool):
        self.action = action
        self.no_param = no_param

    @property
    def dest(self) -> str:
        return self.action.dest

    def __repr__(self):
        return f"SubCommandActionInfo(dest={self.dest})"


_subcommand_index: int = 0
_subcommand_map: "dict[str, set[str]]" = {}
_subcommand_method_infos: "dict[Callable[..., Any], _SubCommandMethodInfo]" = {}


def _get_subcommand_method_info(func: "Callable[..., Any]") -> "_SubCommandMethodInfo":
    info = _subcommand_method_infos.get(func)
    if info is None:
        info = _SubCommandMethodInfo()
        _subcommand_method_infos[func] = info
    return info


class _SubCommandMethodInfo:

    def __init__(self):
        global _subcommand_index
        _subcommand_index += 1
        self.name = None
        self.order = None
        self.pass_args = False
        self.index = _subcommand_index
        self.kwargs: "dict[str, Any] | None" = None
        self.func: "Callable[..., int | None] | None" = None
        self.arguments: "list[_SubCommandMethodArgumentInfo]" = []

    def set_args(self, name: str, **kwargs: "Any") -> "_SubCommandMethodInfo":
        self.name = name
        self.kwargs = _filter_kwargs(kwargs)
        return self

    def __repr__(self):
        return f"SubCommandMethod(func={self.func.__qualname__})"


class _SubCommandMethodArgumentInfo:

    def __init__(self):
        self.args: "tuple[str] | None" = None
        self.kwargs: "dict[str, Any] | None" = None
        self.action: "str | type[Action] | None" = None

    def set_args(self, *args: str, **kwargs: "Any") -> "_SubCommandMethodArgumentInfo":
        self.args = args
        self.kwargs = _filter_kwargs(kwargs)
        return self


def subcommand(
        name: str,
        *,
        help: str = MISSING,
        aliases: "list[str]" = MISSING,
        prog: str = MISSING,
        usage: str = MISSING,
        description: str = MISSING,
        epilog: str = MISSING,
        parents: "list[ArgumentParser]" = MISSING,
        formatter_class: "type[HelpFormatter]" = MISSING,
        prefix_chars: str = MISSING,
        fromfile_prefix_chars: str = MISSING,
        argument_default: "Any" = MISSING,
        conflict_handler: str = MISSING,
        add_help: bool = MISSING,
        allow_abbrev: bool = MISSING,
        pass_args: bool = False,
        order: "str | None" = None) -> "Callable[[Callable[..., int | None]], Callable[..., int | None]]":
    """Subcommand.

    Args:
        name (str): Name to resolve.
        help (str): The help value.
        aliases (List[str]): The aliases value.
        prog (str): The prog value.
        usage (str): The usage value.
        description (str): The description value.
        epilog (str): The epilog value.
        parents (List[ArgumentParser]): The parents value.
        formatter_class (Type[HelpFormatter]): The formatter_class value.
        prefix_chars (str): The prefix_chars value.
        fromfile_prefix_chars (str): The fromfile_prefix_chars value.
        argument_default (Any): The argument_default value.
        conflict_handler (str): The conflict_handler value.
        add_help (bool): The add_help value.
        allow_abbrev (bool): The allow_abbrev value.
        pass_args (bool): The pass_args value.
        order (str): The order value.

    Returns:
        Any: The operation result.

    Raises:
        Exception: Propagates errors raised while completing the operation.
    """

    def decorator(func: "Callable[..., int | None]") -> "Callable[..., int | None]":
        subcommand_info = _get_subcommand_method_info(func)
        subcommand_info.func = func
        subcommand_info.pass_args = pass_args
        subcommand_info.order = order
        subcommand_info.set_args(
            name,
            help=help if help is not MISSING else "",
            aliases=aliases,
            prog=prog,
            usage=usage,
            description=description,
            epilog=epilog,
            parents=parents,
            formatter_class=formatter_class,
            prefix_chars=prefix_chars,
            fromfile_prefix_chars=fromfile_prefix_chars,
            argument_default=argument_default,
            conflict_handler=conflict_handler,
            add_help=add_help,
            allow_abbrev=allow_abbrev
        )

        index = func.__qualname__.rfind(".")
        if index < 0:
            raise SubCommandError(
                f"subcommand decorator must be used in class method, "
                f"but {func.__qualname__} is not")

        class_name = f"{func.__module__}.{func.__qualname__[:index]}"
        func_name = func.__qualname__[index + 1:]

        _subcommand_map.setdefault(class_name, set())
        if func_name in _subcommand_map[class_name]:
            raise SubCommandError(
                f"Redeclared subcommand method '{func.__qualname__}' defined")
        _subcommand_map[class_name].add(func_name)

        return func

    return decorator


def subcommand_argument(
        name_or_flag: str,
        *name_or_flags: str,
        no_param: bool = False,
        action: "str | type[Action]" = MISSING,
        choices: "Iterable[T]" = MISSING,
        const: "Any" = MISSING,
        default: "Any" = MISSING,
        dest: str = MISSING,
        help: str = MISSING,
        metavar: "str | tuple[str, ...]" = MISSING,
        nargs: "int | str" = MISSING,
        required: bool = MISSING,
        type: "type[int | float | str] | Callable[[str], T] | FileType" = MISSING,
        **kwargs: "Any") -> "Callable[[Callable[..., int | None]], Callable[..., int | None]]":
    """Subcommand argument.

    Args:
        name_or_flag (str): The name_or_flag value.
        name_or_flags (str): The name_or_flags value.
        no_param (bool): The no_param value.
        action (Union[str, Type[Action]]): Argparse action being resolved.
        choices (Iterable[T]): The choices value.
        const (Any): The const value.
        default (Any): Value returned when no explicit value is available.
        dest (str): The dest value.
        help (str): The help value.
        metavar (Union[str, Tuple[str, ...]]): The metavar value.
        nargs (Union[int, str]): The nargs value.
        required (bool): The required value.
        type (Union[Type[Union[int, float, str]], Callable[[str], T], FileType]): Target type used to cast the value.
        kwargs (Any): Keyword arguments passed to the operation.

    Returns:
        Any: The operation result.
    """

    def decorator(func: "Callable[..., int | None]") -> "Callable[..., int | None]":
        subcommand_argument_info = _SubCommandMethodArgumentInfo()
        subcommand_argument_info.set_args(
            *[name_or_flag, *name_or_flags],
            no_param=no_param,
            action=action,
            nargs=nargs,
            const=const,
            default=default,
            type=type,
            choices=choices,
            required=required,
            help=help,
            metavar=metavar,
            dest=dest,
            **kwargs
        )

        subcommand_info = _get_subcommand_method_info(func)
        subcommand_info.arguments.append(subcommand_argument_info)

        return func

    return decorator


class _SubCommandInfo:
    node: "SubCommand"
    children: "list[_SubCommandInfo]"

    def __init__(self, subcommand: "SubCommand | _SubCommandInfo"):
        self.node = subcommand.node if isinstance(subcommand, _SubCommandInfo) else subcommand
        self.children = []

    def __repr__(self):
        return f"SubCommandInfo(node={self.node.id})"


def _join_id(*ids: str):
    return "#".join([id for id in ids if id])


class SubCommand(metaclass=abc.ABCMeta):
    """SubCommand."""

    ROOT_ID = _join_id()

    def __init__(self, name: str, description: str, id: str = None, parent_id: str = None, order: str = None):
        self.id = id or _join_id(parent_id, name)
        self.parent_id = parent_id or self.ROOT_ID
        self.name = name
        self.description = description
        self.order = order or self.name
        self._actions = None
        self._print_help = None

    @property
    def has_parent(self) -> bool:
        """Has parent.

        Returns:
            Any: The property value.
        """
        return self.parent_id != self.ROOT_ID

    @property
    def is_group(self) -> bool:
        """Return whether group is true.

        Returns:
            Any: The property value.
        """
        return False

    def create_parser(self, type: "Callable[..., CommandParser]") -> "CommandParser":
        """Create a command parser.

        Args:
            type (Callable[..., CommandParser]): Target type used to cast the value.

        Returns:
            CommandParser: The operation result.
        """
        return type(self.name, help=self.description)

    @abc.abstractmethod
    def run(self, args: "Namespace") -> None:
        """Run.

        Args:
            args (Namespace): Arguments passed to the operation.
        """
        pass

    def __repr__(self):
        return f"{self.__class__.__name__}(id='{self.id}', parent_id='{self.parent_id}', name='{self.name}')"


class SubCommandGroup(SubCommand):
    """Subcommand placeholder that groups child commands."""

    @property
    def is_group(self) -> bool:
        """Return whether group is true.

        Returns:
            Any: The property value.
        """
        return True

    def create_parser(self, type: "Callable[..., CommandParser]") -> "CommandParser":
        """Create a parser for a subcommand group.

        Args:
            type (Callable[..., CommandParser]): Target type used to cast the value.

        Returns:
            CommandParser: The operation result.
        """
        parser = type(self.name, help=self.description)
        self._print_help = parser.print_help
        return parser

    def run(self, args: "Namespace") -> None:
        """Print help for this subcommand group.

        Args:
            args (Namespace): Arguments passed to the operation.

        Returns:
            Any: The operation result.
        """
        if self._print_help is None:
            raise CommandError("subcommand parser is not initialized")
        return self._print_help()


class CommandGroupRef(object):
    """Reference to a parent command group, used as a fallback declaration.

    Returned from a command's ``parent`` property to say "attach me under the
    group with this id; if no real group with that id is registered, materialise
    one from this declaration". If a real group with the same id is already
    registered (provided by another package), the real group wins and this
    declaration is ignored.

    A plain string ``parent`` (e.g. ``"common"``) is *not* a fallback: if that
    group is missing, registration raises :class:`SubCommandError`.
    """

    def __init__(
        self,
        id: "str | None",
        name: str = None,
        description: str = "",
        parent: "str | None" = None,
        order: "str | None" = None,
    ) -> None:
        self.id = id
        self.name = name or id
        self.description = description or ""
        self.parent = parent
        self.order = order or self.name

    def __repr__(self):
        return (
            "CommandGroupRef(id=%r, name=%r, parent=%r)"
            % (self.id, self.name, self.parent)
        )


def _normalize_parent(parent):
    """Resolve a command's ``parent`` value to ``(parent_id, declared_group_ref)``.

    - ``None`` -> ``(ROOT_ID, None)``: a top-level command.
    - :class:`CommandGroupRef` -> ``(ref.id, ref)``: fallback declaration; if the
      group is missing it is materialised from the ref.
    - ``str`` -> ``(str, None)``: attach to an existing group; missing raises.
    """
    if parent is None:
        return SubCommand.ROOT_ID, None
    if isinstance(parent, CommandGroupRef):
        return parent.id, parent
    return parent, None


def _ensure_declared_parent_groups(subcommands):
    """Materialise missing parent groups declared via :class:`CommandGroupRef`.

    A real group already present in ``subcommands`` always wins; its
    CommandGroupRef declarations are ignored. When several CommandGroupRefs
    describe the same absent group they must agree (name/order/parent) or
    :class:`SubCommandError` is raised. Plain-string parents are never
    auto-created, so a missing non-declared parent still raises during validation.
    """
    result = list(subcommands)
    exists = set([item.id for item in result])
    declarations = {}

    # Collect fallback declarations; if a real group already exists, ignore.
    for item in result:
        group = getattr(item, "declared_parent_group", None)
        if group is None:
            continue
        if group.id in exists:
            continue
        existing = declarations.get(group.id)
        if existing is None:
            declarations[group.id] = group
        else:
            _merge_or_validate_group_ref(existing, group)

    changed = True
    while changed:
        changed = False
        for item in list(result):
            parent_id = item.parent_id
            if parent_id == SubCommand.ROOT_ID:
                continue
            if parent_id in exists:
                continue
            group = declarations.get(parent_id)
            if group is None:
                continue
            group_parent_id, group_parent_ref = _normalize_parent(group.parent)
            result.append(SubCommandGroup(
                id=group.id,
                name=group.name,
                description=group.description,
                parent_id=group_parent_id,
                order=group.order,
            ))
            exists.add(group.id)
            changed = True

            # Support a group that itself hangs under another CommandGroupRef.
            # If that real parent already exists, the real group still wins.
            if group_parent_ref is not None:
                if group_parent_ref.id in exists:
                    continue
                existing = declarations.get(group_parent_ref.id)
                if existing is None:
                    declarations[group_parent_ref.id] = group_parent_ref
                else:
                    _merge_or_validate_group_ref(existing, group_parent_ref)

    return tuple(result)


def _merge_or_validate_group_ref(existing, incoming):
    """Two CommandGroupRefs for the same absent group must agree.

    name/order/parent must match exactly; description is filled in loosely (a
    non-empty incoming description is adopted when existing is empty). Any
    mismatch raises :class:`SubCommandError`.
    """
    if existing.name != incoming.name:
        raise SubCommandError(
            "Conflicting command group declaration for %s: name %s != %s"
            % (existing.id, existing.name, incoming.name)
        )
    if existing.order != incoming.order:
        raise SubCommandError(
            "Conflicting command group declaration for %s: order %s != %s"
            % (existing.id, existing.order, incoming.order)
        )
    existing_parent_id, _ = _normalize_parent(existing.parent)
    incoming_parent_id, _ = _normalize_parent(incoming.parent)
    if existing_parent_id != incoming_parent_id:
        raise SubCommandError(
            "Conflicting command group declaration for %s: parent %s != %s"
            % (existing.id, existing_parent_id, incoming_parent_id)
        )
    if not existing.description and incoming.description:
        existing.description = incoming.description
    return existing


class _SubCommandMethod(SubCommand):

    def __init__(self, info: "_SubCommandMethodInfo", target: "Any",
                 id: str = None, parent_id: str = None,
                 order: str = None):
        super().__init__(
            id=id,
            parent_id=parent_id,
            name=info.name,
            description=info.kwargs.get("description", None) or info.kwargs.get("help", None) or "",
            order=order,
        )
        self.info = info
        self.target = target

    def create_parser(self, type: "Callable[..., CommandParser]") -> "CommandParser":

        actions = []
        self._actions = actions
        method = getattr(self.target, self.info.func.__name__)
        parser = type(self.name, **self.info.kwargs)

        for argument in reversed(self.info.arguments):
            argument_args = argument.args
            argument_kwargs = dict(argument.kwargs)

            no_param = argument_kwargs.pop("no_param", MISSING)

            # Resolve dest so annotated arguments match method parameters.
            dest = argument_kwargs.get("dest", MISSING)
            if dest is MISSING:
                prefix_chars = parser.prefix_chars
                if not argument_args or len(argument_args) == 1 and argument_args[0][0] not in prefix_chars:
                    dest = argument_args[0]
                    argument_kwargs["required"] = MISSING  # Positional arguments cannot set required here.
                    # Positional + choices + no explicit metavar: Python 3.6's
                    # argparse emits "argument None" for invalid-choice errors.
                    # Setting metavar=DEST.upper() gives the error a stable name.
                    if "choices" in argument_kwargs and "metavar" not in argument_kwargs:
                        argument_kwargs["metavar"] = dest.replace("-", "_").upper()
                else:
                    option_strings = []
                    long_option_strings = []
                    for option_string in argument_args:
                        option_strings.append(option_string)
                        if len(option_string) > 1 and option_string[1] in prefix_chars:
                            long_option_strings.append(option_string)
                    dest_option_string = long_option_strings[0] if long_option_strings else option_strings[0]
                    dest = dest_option_string.lstrip(prefix_chars)
                    if not dest:
                        raise SubCommandError(
                            f"Parse subcommand argument dest error, "
                            f"{self.info} argument `{', '.join(argument_args)}` require dest=...")
                    dest = dest.replace('-', '_')
                    argument_kwargs["dest"] = dest

            # Validate that dest exists in the method signature.
            signature = inspect.signature(method)
            if not no_param and dest and dest not in signature.parameters:
                raise SubCommandError(
                    f"Check subcommand parameter error, {self.info} has no `{dest}` parameter. {os.linesep}"
                    f"You can do any of the following: {os.linesep}"
                    f"1. add `{dest}` parameter to {self.info}, {os.linesep}"
                    f"2. add `no_param=True` parameter to argument `{', '.join(argument_args)}`.")

            # Resolve string annotations (e.g. when annotations are string-quoted).
            try:
                import typing
                type_hints = typing.get_type_hints(method)
            except Exception:
                type_hints = {}

            def _resolve_annotation(param):
                if param is None:
                    return inspect.Parameter.empty
                hint = type_hints.get(param.name, inspect.Parameter.empty)
                if hint is not inspect.Parameter.empty:
                    return hint
                return param.annotation

            # Fill defaults from method parameter annotations.
            parameter = signature.parameters[dest] if not no_param else None
            if "config" in argument_kwargs:
                config = argument_kwargs.get("config")
                if isinstance(config, ConfigField):
                    if "action" not in argument_kwargs:
                        argument_kwargs.setdefault("action", ConfigAction)
                        annotation = _resolve_annotation(parameter)
                        if annotation not in (inspect.Parameter.empty,) and annotation in (int, float, str, bool):
                            argument_kwargs.setdefault("type", annotation)
                    argument_kwargs.setdefault("required", False)

            if parameter and "default" not in argument_kwargs:
                if parameter.default != signature.empty:
                    argument_kwargs.setdefault("default", parameter.default)
                    argument_kwargs.setdefault("required", False)
                else:
                    argument_kwargs.setdefault("required", True)

            if parameter and "action" not in argument_kwargs:
                annotation = _resolve_annotation(parameter)
                if annotation is not inspect.Parameter.empty:
                    if annotation in (int, float, str):
                        argument_kwargs.setdefault("type", annotation)
                    elif annotation is bool:
                        if argument_kwargs.get("default", False):
                            argument_kwargs.setdefault("action", "store_false")
                        else:
                            argument_kwargs.setdefault("action", "store_true")

            action = parser.add_argument(*argument_args, **_filter_kwargs(argument_kwargs))
            actions.append(_SubCommandActionInfo(action, no_param=no_param))

        return parser

    def run(self, args: "Namespace") -> "int | None":
        method = getattr(self.target, self.info.func.__name__)

        actions = self._actions
        if actions is None:
            raise CommandError("subcommand parser is not initialized")

        method_args = []
        if self.info.pass_args:
            method_args.append(args)

        method_kwargs = dict()
        for action in actions:
            if not action.no_param:
                method_kwargs[action.dest] = getattr(args, action.dest)

        return method(*method_args, **method_kwargs)


class SubCommandWrapper(SubCommand):

    """Wrap a BaseCommand so it can be used as a subcommand."""
    def __init__(self, command: "BaseCommand",
                 id: str = None, parent_id: str = None,
                 name: str = None, description: str = None,
                 order: str = None):
        parent_id_value, declared_parent_group = _normalize_parent(command.parent)
        super().__init__(
            id=id or _join_id(parent_id_value, command.name),
            parent_id=parent_id or parent_id_value,
            name=name or command.name,
            description=description or command.description,
            order=order or command.order,
        )
        self.command = command
        # Internal only: a fallback group declaration (CommandGroupRef) carried
        # from the command's `parent`, used to materialise a missing parent
        # group. Not part of the command-author API.
        self.declared_parent_group = declared_parent_group

    def create_parser(self, type: "Callable[..., CommandParser]") -> "CommandParser":
        """Create a parser for the wrapped command.

        Args:
            type (Callable[..., CommandParser]): Target type used to cast the value.

        Returns:
            CommandParser: The operation result.
        """
        return self.command.create_parser(self.name, help=self.description, type=type)

    def run(self, args: "Namespace") -> int:
        """Run the wrapped command.

        Args:
            args (Namespace): Arguments passed to the operation.

        Returns:
            Any: The operation result.
        """
        return self.command(args)


class SubCommandMixin:

    """Mixin that discovers, registers, and prints subcommands."""
    def walk_subcommands(self: "BaseCommand", target: "Any", parent_id: "str | None" = None) -> "Generator[SubCommand, None, None]":
        """Yield subcommands discovered from a target object.

        Args:
            target (Any): The target value.
            parent_id (str): The parent_id value.

        Returns:
            Generator[SubCommand, None, None]: The operation result.
        """

        if isinstance(target, SubCommand):
            yield target

        elif isinstance(target, (list, tuple, set, GeneratorType)):
            for item in target:
                yield from self.walk_subcommands(item, parent_id=parent_id)

        elif isinstance(target, _CommandInfo):
            if target.command:
                yield SubCommandWrapper(
                    target.command,
                    id=_join_id(parent_id, target.id),
                    parent_id=_join_id(parent_id, target.parent_id),
                    order=target.order,
                )
            else:
                yield SubCommandGroup(
                    target.command_name, target.command_description,
                    id=_join_id(parent_id, target.id),
                    parent_id=_join_id(parent_id, target.parent_id),
                    order=target.order,
                )

        elif isinstance(target, ModuleType):
            for c in iter_module_commands(target, onerror="warn"):
                if c.command:
                    yield SubCommandWrapper(
                        c.command,
                        id=_join_id(parent_id, c.id),
                        parent_id=_join_id(parent_id, c.parent_id),
                        order=c.order,
                    )
                else:
                    yield SubCommandGroup(
                        c.command_name, c.command_description,
                        id=_join_id(parent_id, c.id),
                        parent_id=_join_id(parent_id, c.parent_id),
                        order=c.order,
                    )

        else:
            subcommand_map: "dict[str, list[_SubCommandMethod]]" = {}
            for clazz in target.__class__.mro():
                class_name = f"{clazz.__module__}.{clazz.__qualname__}"
                if class_name not in _subcommand_map:
                    continue
                for func_name in _subcommand_map[class_name]:
                    if not hasattr(clazz, func_name):
                        continue
                    func = getattr(clazz, func_name)
                    if func not in _subcommand_method_infos:
                        continue
                    info: "_SubCommandMethodInfo" = _subcommand_method_infos[func]
                    subcommand = _SubCommandMethod(info, target, parent_id=parent_id, order=info.order)
                    subcommand_map.setdefault(subcommand.name, list())
                    subcommand_map[info.name].append(subcommand)

            command_infos: "list[tuple[int, _SubCommandMethod]]" = []
            for name, subcommands in subcommand_map.items():
                command_infos.append((min([c.info.index for c in subcommands]), subcommands[0]))
            for _, subcommand in sorted(command_infos, key=lambda o: o[0]):
                yield subcommand

    def add_subcommands(
            self: "BaseCommand",
            parser: "CommandParser | None" = None,
            target: "Any" = None,
            required: bool = False,
            sort: bool = False,
    ) -> "list[_SubCommandInfo]":
        """Register discovered subcommands on a parser.

        Args:
            parser (CommandParser): Argument parser to configure or inspect.
            target (Any): The target value.
            required (bool): The required value.
            sort (bool): The sort value.

        Returns:
            List[_SubCommandInfo]: The operation result.

        Raises:
            Exception: Propagates errors raised while completing the operation.
        """
        target = target or self
        target_parser = parser or self._argument_parser

        subcommand_list = tuple(self.walk_subcommands(target))
        subcommand_list = _ensure_declared_parent_groups(subcommand_list)
        subcommand_maps = {subcommand_list[i].id: (i, subcommand_list[i]) for i in range(len(subcommand_list))}
        subcommand_index = {}
        for i in range(len(subcommand_list)):
            temp_subcommand = subcommand = subcommand_list[i]
            group = [subcommand.order if sort else i]
            while temp_subcommand.has_parent:
                if temp_subcommand.parent_id not in subcommand_maps:
                    raise SubCommandError(f"{temp_subcommand} has no parent subparser")
                parent_index, parent_subcommand = subcommand_maps.get(temp_subcommand.parent_id)
                if parent_subcommand is None or not parent_subcommand.is_group:
                    raise SubCommandError(f"{temp_subcommand} has no parent subparser")
                group.append(parent_subcommand.order if sort else parent_index)
                temp_subcommand = parent_subcommand
            subcommand_index[subcommand.id] = tuple(reversed(group))

        parsers = {}
        root_parser = parser.add_subparsers(metavar="COMMAND", help="Command Help")
        root_parser.required = required
        subcommand_infos: "list[_SubCommandInfo]" = sorted(
            [_SubCommandInfo(subcommand) for subcommand in subcommand_list],
            key=lambda x: subcommand_index.get(x.node.id)
        )
        for subcommand_info in subcommand_infos:
            subcommand = subcommand_info.node

            parent_parser = root_parser
            if subcommand.has_parent:
                parent_parser = parsers.get(subcommand.parent_id, None)
                if not parent_parser:
                    raise SubCommandError(f"{subcommand} has no parent subparser")

            parser = subcommand.create_parser(type=functools.partial(parent_parser.add_parser, command=self))
            parser.set_defaults(**{f"linktools_subcommand_{id(self):x}": subcommand})
            self.init_global_arguments(parser)

            if subcommand.is_group:
                subparser = parser.add_subparsers(metavar="COMMAND", help="Command Help")
                subparser.required = False
                parsers[subcommand.id] = subparser

            # Handle BaseCommand separately because init_arguments may add subcommands.
            if isinstance(subcommand, SubCommandWrapper):
                sub_subcommand_infos = parser.get_default(f"linktools_subcommands_{id(subcommand.command):x}")
                if sub_subcommand_infos:
                    subcommand_info.children.extend(
                        sub_subcommand_infos
                    )

        target_parser.set_defaults(**{f"linktools_subcommands_{id(self):x}": subcommand_infos})

        return subcommand_infos

    def parse_subcommand(self: "BaseCommand", args: "Namespace") -> "SubCommand | None":
        """Return the selected subcommand from parsed args.

        Args:
            args (Namespace): Arguments passed to the operation.

        Returns:
            Optional[SubCommand]: The operation result.
        """
        name = f"linktools_subcommand_{id(self):x}"
        if hasattr(args, name):
            subcommand = getattr(args, name)
            if isinstance(subcommand, SubCommand):
                return subcommand

        return None

    def run_subcommand(self: "BaseCommand", args: "Namespace") -> "int | None":
        """Run the selected subcommand from parsed args.

        Args:
            args (Namespace): Arguments passed to the operation.

        Returns:
            Optional[int]: The operation result.

        Raises:
            Exception: Propagates errors raised while completing the operation.
        """
        subcommand = self.parse_subcommand(args)
        if subcommand:
            return subcommand.run(args)
        raise NotFoundSubCommand("Not found subcommand")

    def print_subcommands(
            self: "BaseCommand",
            args: "Namespace",
            root: "SubCommand | None" = None,
            max_level: "int | None" = None
    ) -> None:
        """Print the registered subcommand tree.

        Args:
            args (Namespace): Arguments passed to the operation.
            root (SubCommand): The root value.
            max_level (int): The max_level value.

        Raises:
            Exception: Propagates errors raised while completing the operation.
        """
        name = f"linktools_subcommands_{id(self):x}"
        if not hasattr(args, name):
            raise SubCommandError("No subcommand has been added yet")

        root_id = SubCommand.ROOT_ID
        description = "All commands"
        if root:
            root_id = root.id
            if root.description:
                description = root.description
        elif self.description:
            description = self.description

        if is_rich_available():
            from rich import get_console
            from rich.tree import Tree

            tree = self._make_subcommand_tree(
                Tree(f"📎 {description}"),
                getattr(args, name),
                root_id,
                max_level,
            )

            console = get_console()
            if self.environ.description != NotImplemented:
                console.print(self.environ.description, highlight=False)
            console.print(tree, highlight=False)
        else:
            if self.environ.description != NotImplemented:
                print(self.environ.description)
            print(description)
            self._print_subcommand_tree(getattr(args, name), root_id, max_level=max_level)

    def _print_subcommand_tree(
            self: "BaseCommand",
            infos: "list[_SubCommandInfo]",
            root_id: str,
            max_level: "int | None",
            level: int = 0,
    ) -> None:
        """
        Print a plain-text command tree when rich is unavailable.
        """
        for info in infos:
            if info.node.parent_id != root_id:
                continue

            current_level = level + 1
            if max_level is not None and current_level > max_level:
                continue

            prefix = "  " * level
            marker = "*" if info.node.is_group or info.children else "-"
            text = f"{prefix}{marker} {info.node.name}"
            if info.node.description:
                text = f"{text}: {info.node.description}"
            print(text)

            child_infos = info.children or infos
            child_root_id = SubCommand.ROOT_ID if info.children else info.node.id
            self._print_subcommand_tree(
                child_infos,
                child_root_id,
                max_level=max_level,
                level=current_level,
            )

    def _make_subcommand_tree(
            self: "BaseCommand",
            tree: "Tree",
            infos: "list[_SubCommandInfo]",
            root_id: str,
            max_level: "int | None"
    ) -> "Tree":
        nodes: "dict[str, tuple[Tree, int]]" = {}
        for info in infos:
            if info.node.parent_id == root_id:
                parent_node, parent_node_level = tree, 0
            elif info.node.parent_id in nodes:
                parent_node, parent_node_level = nodes.get(info.node.parent_id)
            else:
                self.logger.debug(f"Not found parent node id `{info.node.parent_id}`, skip")
                continue

            current_node_level = parent_node_level + 1
            current_node_expanded = max_level is None or max_level > current_node_level

            dbg_msg = f" [dim](group={info.node.is_group}, id={info.node.id}, order={info.node.order})[/dim]" \
                if _debug_enabled(self.environ) \
                else ""

            if info.node.is_group or info.children:
                logo = "📖" if current_node_expanded else "📘"
                text = f"{logo} [underline red]{info.node.name}[/underline red]{dbg_msg}"
                if info.node.description:
                    text = f"{text}: {info.node.description}"
                current_node = parent_node.add(text, expanded=current_node_expanded)
                nodes[info.node.id] = current_node, current_node_level
            else:
                text = f"👉 [bold red]{info.node.name}[/bold red]{dbg_msg}"
                if info.node.description:
                    text = f"{text}: {info.node.description}"
                current_node = parent_node.add(text, expanded=current_node_expanded)
                nodes[info.node.id] = current_node, current_node_level

            if info.children:
                current_max_level = max_level - current_node_level if max_level is not None else None
                self._make_subcommand_tree(
                    current_node,
                    info.children,
                    SubCommand.ROOT_ID,
                    current_max_level
                )

        return tree


class BaseCommand(SubCommandMixin, metaclass=abc.ABCMeta):
    """Base class for executable command-line commands."""

    @property
    def name(self) -> str:
        """Return the name.

        Returns:
            str: The property value.
        """
        name = self.__module__
        index = name.rfind(".")
        if index >= 0:
            name = name[index + 1:]
        return name

    @property
    def parent(self) -> "CommandGroupRef | str | None":
        """Return the parent command id, or a :class:`CommandGroupRef` to
        declare a fallback group to materialise if none is registered.

        Returns:
            CommandGroupRef | str | None: The property value.
        """
        return None

    @property
    def environ(self) -> "BaseEnviron":
        """Return the command environment.

        Returns:
            BaseEnviron: The property value.
        """
        return environ

    @property
    def config(self) -> "dict":
        """Return the configuration object.

        Returns:
            dict: The property value.
        """
        return self.environ.config

    @property
    def logger(self) -> "logging.Logger":
        """Return the root logger.

        Returns:
            logging.Logger: The property value.
        """
        return self.environ.logger

    @cached_property
    def description(self) -> str:
        """Description.

        Returns:
            str: The operation result.
        """
        return textwrap.dedent((self.__doc__ or "")).strip()

    @cached_property
    def order(self) -> str:
        """Order.

        Returns:
            str: The operation result.
        """
        return self.name

    @property
    def known_errors(self) -> "list[type[BaseException]]":
        """Return command-specific known error types.

        Returns:
            List[Type[BaseException]]: The property value.
        """
        return []

    @abc.abstractmethod
    def init_arguments(self, parser: "CommandParser") -> None:
        """Initialize parser arguments.

        Args:
            parser (CommandParser): Argument parser to configure or inspect.
        """
        pass

    @abc.abstractmethod
    def run(self, args: "Namespace") -> "int | None":
        """Run.

        Args:
            args (Namespace): Arguments passed to the operation.

        Returns:
            Optional[int]: The operation result.
        """
        pass

    def create_parser(
            self,
            *args: "Any",
            type: "Callable[..., CommandParser]" = CommandParser,
            formatter_class: "type[HelpFormatter]" = RawDescriptionHelpFormatter,
            conflict_handler: str = "resolve",
            **kwargs: "Any"
    ) -> "CommandParser":
        """Create a command parser.

        Args:
            args (Any): Arguments passed to the operation.
            type (Callable[..., CommandParser]): Target type used to cast the value.
            formatter_class (Type[HelpFormatter]): The formatter_class value.
            conflict_handler: The conflict_handler value.
            kwargs (Any): Keyword arguments passed to the operation.

        Returns:
            CommandParser: The operation result.
        """
        description = kwargs.pop("description", None)
        if not description:
            description = self.description.strip()
            if description and self.environ.description != NotImplemented:
                description += os.linesep + os.linesep
                description += self.environ.description
        parser = type(
            *args,
            command=self,
            description=description,
            formatter_class=formatter_class,
            conflict_handler=conflict_handler,
            **kwargs
        )
        self.init_base_arguments(parser)
        self.init_arguments(parser)
        return parser

    @cached_property(lock=True)
    def _argument_parser(self) -> "CommandParser":
        parser = self.create_parser()
        self.init_global_arguments(parser)
        return parser

    def init_base_arguments(self, parser: "CommandParser") -> None:
        """Initialize base parser arguments.

        Args:
            parser (CommandParser): Argument parser to configure or inspect.
        """
        pass

    def init_global_arguments(self, parser: "CommandParser") -> None:
        """Initialize global parser arguments.

        Args:
            parser (CommandParser): Argument parser to configure or inspect.
        """

        environ = self.environ
        prefix = parser.prefix_chars[0] if parser.prefix_chars else "-"

        class VerboseAction(Action):

            def __call__(self, parser, namespace, values, option_string=None):
                environ.logging.set_level("root", logging.DEBUG)

        class SilentAction(Action):

            def __call__(self, parser, namespace, values, option_string=None):
                logging.disable(logging.CRITICAL)

        class DebugAction(Action):

            def __call__(self, parser, namespace, values, option_string=None):
                environ.global_config["DEBUG"] = True
                environ.logging.set_level(environ.name, logging.DEBUG)

        class NoInputAction(Action):

            def __call__(self, parser, namespace, values, option_string=None):
                from ..rich import set_no_input
                set_no_input(True)

        class LogTimeAction(BooleanOptionalAction):

            def __call__(self, parser, namespace, values, option_string=None):
                if option_string in self.option_strings:
                    value = not option_string.startswith("--no-")
                    self.command.environ.logging.set_show_time(value)

        class LogLevelAction(BooleanOptionalAction):

            def __call__(self, parser, namespace, values, option_string=None):
                if option_string in self.option_strings:
                    value = not option_string.startswith("--no-")
                    self.command.environ.logging.set_show_level(value)

        group = parser.add_argument_group(title="log options")
        group.add_argument(f"{prefix}{prefix}verbose", action=VerboseAction, nargs=0, const=True, dest=SUPPRESS,
                           help="increase log verbosity")
        group.add_argument(f"{prefix}{prefix}silent", action=SilentAction, nargs=0, const=True, dest=SUPPRESS,
                           help="disable all log output")
        group.add_argument(f"{prefix}{prefix}debug", action=DebugAction, nargs=0, const=True, dest=SUPPRESS,
                           help=f"increase {self.environ.name}'s log verbosity, and enable debug mode")
        group = parser.add_argument_group(title="interaction options")
        group.add_argument(f"{prefix}{prefix}yes", action=NoInputAction, nargs=0, const=True, dest=SUPPRESS,
                           help="answer yes/accept defaults to all prompts")

        if self.environ.logging.get_handler() is not None:
            group.add_argument(f"{prefix}{prefix}time", action=LogTimeAction, dest=SUPPRESS,
                               help="show log time")
            group.add_argument(f"{prefix}{prefix}level", action=LogLevelAction, dest=SUPPRESS,
                               help="show log level")

        if self.environ.version != NotImplemented:
            parser.add_argument(
                f"{prefix}{prefix}version", action="version", version=self.environ.version
            )

    @property
    def main(self) -> "CommandMain":
        """Return the command entry point.

        Returns:
            CommandMain: The property value.
        """
        return CommandMain(self, show_log_level=True, show_log_time=False)

    def __call__(self, args: "list[str] | Namespace" = None) -> int:
        """Call.

        Args:
            args (Union[List[str], Namespace]): Arguments passed to the operation.

        Returns:
            int: The operation result.
        """
        try:
            if not isinstance(args, Namespace):
                parser = ArgParseComplete.autocomplete(self._argument_parser)
                args = parser.parse_args(args)

            exit_code = self.run(args) or 0

        except (CommandError, *self.known_errors) as e:
            # Map the error's domain to a stable exit code.
            from ._exitcodes import exit_code_for
            exit_code = exit_code_for(e)
            error_type, error_message = e.__class__.__name__, str(e).strip()
            self.logger.error(
                f"{error_type}: {error_message}" if error_message else error_type,
                exc_info=True if _debug_enabled(self.environ) else None,
            )

        except KeyboardInterrupt:
            from ._exitcodes import EXIT_INTERRUPT
            exit_code = EXIT_INTERRUPT
            self.logger.warning("Interrupted")

        return exit_code


class BaseCommandGroup(BaseCommand, metaclass=abc.ABCMeta):

    """Base command that dispatches to registered subcommands."""
    def init_subcommands(self) -> "Any":
        """Return the target used to discover subcommands.

        Returns:
            Any: The operation result.
        """
        return self

    def init_arguments(self, parser: "CommandParser") -> None:
        """Register subcommands on the parser.

        Args:
            parser (CommandParser): Argument parser to configure or inspect.
        """
        self.add_subcommands(
            parser=parser,
            target=self.init_subcommands(),
        )

    def run(self, args: "Namespace") -> "int | None":
        """Dispatch to the selected subcommand or print the command tree.

        Args:
            args (Namespace): Arguments passed to the operation.

        Returns:
            Optional[int]: The operation result.
        """
        subcommand = self.parse_subcommand(args)
        if not subcommand or subcommand.is_group:
            return self.print_subcommands(args, subcommand, max_level=2)
        return subcommand.run(args)


class CommandMain:

    """Callable command entry point with logging and error handling."""
    def __init__(
            self,
            command: "BaseCommand", *,
            show_log_time: bool = False,
            show_log_level: bool = False,
            expand_user: bool = True,
            exit_on_return: bool = False,
    ):
        self._command = command
        self.show_log_level = show_log_level
        self.show_log_time = show_log_time
        self.expand_user = expand_user
        self.exit_on_return = exit_on_return

    @property
    def command(self) -> "BaseCommand":
        """Command.

        Returns:
            BaseCommand: The property value.
        """
        return self._command

    def init_logging(
        self,
        level: int = logging.INFO,
        log_file: "str | None" = None,
    ) -> None:
        """Initialize logging for command execution through the command's
        own LoggingManager."""
        self.command.environ.logging.configure(
            level=level,
            log_file=log_file,
            rich=is_rich_available(),
            show_time=self.show_log_time,
            show_level=self.show_log_level,
        )

    def __call__(self, args: "list[str]" = None) -> int:
        """Call.

        Args:
            args (List[str]): Arguments passed to the operation.

        Returns:
            int: The operation result.
        """
        try:
            environ = self.command.environ
            level_name = environ.get_config("LOG_LEVEL", str, default="INFO")
            level = getattr(logging, str(level_name).upper(), logging.INFO)
            log_file = environ.get_config("LOG_FILE", str, default=None) or None
            self.init_logging(level=level, log_file=log_file)
            if self.expand_user:
                args = sys.argv[1:] if args is None else args
                args = tuple(os.path.expanduser(arg) for arg in args)
            result = self.command(args=args)
        except SystemExit as e:
            result = e.code
        except (KeyboardInterrupt, EOFError) as e:
            error_type, error_message = e.__class__.__name__, str(e).strip()
            self.command.logger.error(
                f"{error_type}: {error_message}" if error_message else error_type,
                exc_info=True if _debug_enabled(self.command.environ) else None,
            )
            result = 130  # https://tldp.org/LDP/abs/html/exitcodes.html#EXITCODESREF
        except Exception:
            if _debug_enabled(self.command.environ) and is_rich_available():
                from rich import get_console
                get_console().print_exception(show_locals=True)
            else:
                self.command.logger.error(traceback.format_exc())
            result = 1

        if self.exit_on_return:
            sys.exit(result)

        return result
