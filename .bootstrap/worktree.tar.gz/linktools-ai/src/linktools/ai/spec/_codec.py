#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Bytes codecs for declaration DTOs."""

import json
import re
from collections.abc import Mapping
from typing import Protocol, TypeVar, cast

import yaml

from ..core import canonical_string_tuple
from ..errors import AIError, ErrorCode
from ._contract import AgentSpec, AgentUsageLimits, MCPServerSpec, SkillSpec

SpecT = TypeVar("SpecT")
_AGENT_FIELDS = frozenset(
    {
        "id",
        "revision",
        "model",
        "system_prompt",
        "instructions",
        "allow_tools",
        "usage_limits",
    }
)
_SKILL_FIELDS = frozenset({"id", "revision", "content"})
_MCP_FIELDS = frozenset({"id", "revision", "command", "args"})


class SpecCodec(Protocol[SpecT]):
    def encode(self, value: SpecT) -> bytes: ...
    def decode(self, data: bytes) -> SpecT: ...


class AgentSpecCodec:
    def encode(self, value: AgentSpec) -> bytes:
        return _encode(
            {
                "id": value.id,
                "revision": value.revision,
                "model": value.model,
                "system_prompt": value.system_prompt,
                "instructions": list(value.instructions),
                "allow_tools": list(value.allow_tools),
                "usage_limits": None
                if value.usage_limits is None
                else {
                    "model_requests": value.usage_limits.model_requests,
                    "tool_calls": value.usage_limits.tool_calls,
                    "input_tokens": value.usage_limits.input_tokens,
                    "output_tokens": value.usage_limits.output_tokens,
                    "total_tokens": value.usage_limits.total_tokens,
                },
            }
        )

    def decode(self, data: bytes) -> AgentSpec:
        try:
            raw = _decode(data)
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as error:
            raise AIError(ErrorCode.OUTPUT_CONTRACT_INVALID, "agent spec is invalid") from error
        if set(raw) - _AGENT_FIELDS:
            raise AIError(ErrorCode.OUTPUT_CONTRACT_INVALID, "agent spec fields are invalid")
        if "id" not in raw:
            raise AIError(ErrorCode.OUTPUT_CONTRACT_INVALID, "agent spec requires id")
        identity = raw["id"]
        revision = raw.get("revision", 1)
        model = raw.get("model", "default")
        if not isinstance(identity, str) or not identity.strip():
            raise AIError(ErrorCode.OUTPUT_CONTRACT_INVALID, "agent id must be a non-empty string")
        if not isinstance(revision, int) or isinstance(revision, bool) or revision < 1:
            raise AIError(ErrorCode.OUTPUT_CONTRACT_INVALID, "agent revision must be a positive integer")
        if not isinstance(model, str) or not model.strip():
            raise AIError(ErrorCode.OUTPUT_CONTRACT_INVALID, "agent model must be a non-empty string")
        system_prompt = raw.get("system_prompt", "")
        if not isinstance(system_prompt, str):
            raise AIError(ErrorCode.OUTPUT_CONTRACT_INVALID, "system_prompt must be a string")
        instructions = raw.get("instructions", [])
        if not isinstance(instructions, list) or any(not isinstance(item, str) for item in instructions):
            raise AIError(ErrorCode.OUTPUT_CONTRACT_INVALID, "instructions must be a string array")
        try:
            return AgentSpec(
                id=identity,
                revision=revision,
                model=model,
                system_prompt=system_prompt,
                instructions=tuple(instructions),
                allow_tools=_strict_allowlist(raw, "allow_tools", ("*",)),
                usage_limits=_decode_usage_limits(raw.get("usage_limits")),
            )
        except AIError:
            raise
        except (TypeError, ValueError) as error:
            raise AIError(ErrorCode.OUTPUT_CONTRACT_INVALID, "agent spec is invalid") from error


class SkillSpecCodec:
    def encode(self, value: SkillSpec) -> bytes:
        return _encode({"id": value.id, "revision": value.revision, "content": value.content})

    def decode(self, data: bytes) -> SkillSpec:
        try:
            raw = _decode(data)
            if set(raw) != _SKILL_FIELDS:
                raise ValueError("skill spec fields are invalid")
            identity = raw["id"]
            revision = raw["revision"]
            content = raw["content"]
            if not isinstance(identity, str):
                raise ValueError("skill id must be a string")
            if not isinstance(revision, int) or isinstance(revision, bool):
                raise ValueError("skill revision must be an integer")
            if not isinstance(content, str):
                raise ValueError("skill content must be a string")
            return SkillSpec(identity, revision, content)
        except AIError:
            raise
        except (KeyError, TypeError, UnicodeDecodeError, json.JSONDecodeError, ValueError) as error:
            raise AIError(ErrorCode.OUTPUT_CONTRACT_INVALID, "skill spec is invalid") from error


class SkillMarkdownSpecCodec:
    """Decode standard SKILL.md documents without rewriting their text."""

    def encode(self, value: SkillSpec) -> bytes:
        try:
            frontmatter, revision = _parse_skill_markdown(value.content)
        except AIError:
            raise
        except Exception as error:
            raise AIError(ErrorCode.OUTPUT_CONTRACT_INVALID) from error
        if frontmatter["name"] != value.id:
            raise AIError(ErrorCode.ASSET_CONTENT_MISMATCH)
        if (
            not isinstance(value.revision, int)
            or isinstance(value.revision, bool)
            or value.revision < 1
            or revision != value.revision
        ):
            raise AIError(ErrorCode.ASSET_CONTENT_MISMATCH)
        try:
            return value.content.encode("utf-8")
        except Exception as error:
            raise AIError(ErrorCode.OUTPUT_CONTRACT_INVALID) from error

    def decode(self, data: bytes) -> SkillSpec:
        try:
            content = data.decode("utf-8")
            frontmatter, revision = _parse_skill_markdown(content)
            return SkillSpec(cast(str, frontmatter["name"]), revision, content)
        except AIError:
            raise
        except Exception as error:
            raise AIError(ErrorCode.OUTPUT_CONTRACT_INVALID) from error


class SkillMarkdownSpecAdapter:
    """Translate standard local skill names to complete logical ids."""

    def to_logical(self, logical_id: str, value: SkillSpec) -> SkillSpec:
        local_name = logical_id.rsplit("/", 1)[-1]
        if value.id != local_name:
            raise AIError(ErrorCode.ASSET_CONTENT_MISMATCH)
        return SkillSpec(logical_id, value.revision, value.content)

    def to_storage(self, logical_id: str, value: SkillSpec) -> SkillSpec:
        if value.id != logical_id:
            raise AIError(ErrorCode.ASSET_CONTENT_MISMATCH)
        return SkillSpec(logical_id.rsplit("/", 1)[-1], value.revision, value.content)


def retarget_skill_markdown(content: str, local_name: str) -> str:
    """Rewrite the canonical frontmatter name during a logical rename."""
    lines = content.splitlines(keepends=True)
    closing = next(
        (index for index, line in enumerate(lines[1:], 1) if line.rstrip("\r\n") == "---"),
        None,
    )
    if closing is None:
        raise AIError(ErrorCode.OUTPUT_CONTRACT_INVALID)
    frontmatter, _ = _parse_skill_markdown(content)
    frontmatter["name"] = local_name
    encoded = yaml.safe_dump(
        frontmatter,
        allow_unicode=True,
        default_flow_style=False,
        sort_keys=True,
    )
    return f"---\n{encoded}---\n{''.join(lines[closing + 1:])}"


class MCPServerSpecCodec:
    def encode(self, value: MCPServerSpec) -> bytes:
        return _encode({"id": value.id, "revision": value.revision, "command": value.command, "args": list(value.args)})

    def decode(self, data: bytes) -> MCPServerSpec:
        try:
            raw = _decode(data)
            if set(raw) - _MCP_FIELDS or any(name not in raw for name in ("id", "revision", "command")):
                raise ValueError("MCP server spec fields are invalid")
            identity = raw["id"]
            revision = raw["revision"]
            command = raw["command"]
            args = raw.get("args", [])
            if not isinstance(identity, str):
                raise ValueError("MCP server id must be a string")
            if not isinstance(revision, int) or isinstance(revision, bool):
                raise ValueError("MCP server revision must be an integer")
            if not isinstance(command, str):
                raise ValueError("MCP server command must be a string")
            if not isinstance(args, list) or any(not isinstance(item, str) for item in args):
                raise ValueError("MCP server args must be a string array")
            return MCPServerSpec(identity, revision, command, tuple(args))
        except AIError:
            raise
        except (KeyError, TypeError, UnicodeDecodeError, json.JSONDecodeError, ValueError) as error:
            raise AIError(ErrorCode.OUTPUT_CONTRACT_INVALID, "MCP server spec is invalid") from error


def _encode(value: "dict[str, object]") -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode("utf-8")


def _decode(data: bytes) -> "dict[str, object]":
    value = json.loads(data.decode("utf-8"))
    if not isinstance(value, dict):
        raise ValueError("spec payload must be a JSON object")
    return value


def _strict_allowlist(raw: Mapping[str, object], name: str, default: "tuple[str, ...]") -> "tuple[str, ...]":
    value = raw.get(name, list(default))
    if not isinstance(value, list):
        raise AIError(ErrorCode.OUTPUT_CONTRACT_INVALID, f"{name} must be a JSON array")
    try:
        return canonical_string_tuple(value, field=name)
    except AIError as error:
        raise AIError(ErrorCode.OUTPUT_CONTRACT_INVALID, f"{name} is invalid") from error


def _decode_usage_limits(value: object) -> "AgentUsageLimits | None":
    if value is None:
        return None
    if not isinstance(value, Mapping):
        raise AIError(ErrorCode.OUTPUT_CONTRACT_INVALID, "usage_limits must be an object or null")
    names = {
        "model_requests",
        "tool_calls",
        "input_tokens",
        "output_tokens",
        "total_tokens",
    }
    if set(value) != names:
        raise AIError(ErrorCode.OUTPUT_CONTRACT_INVALID, "usage_limits fields are invalid")
    try:
        return AgentUsageLimits(**{name: value[name] for name in names})
    except (TypeError, ValueError) as error:
        raise AIError(ErrorCode.OUTPUT_CONTRACT_INVALID, "usage_limits values are invalid") from error


_SKILL_NAME = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")


class _StrictSafeLoader(yaml.SafeLoader):
    pass


def _construct_mapping(loader: _StrictSafeLoader, node: yaml.nodes.MappingNode, deep: bool = False) -> dict[object, object]:
    mapping: dict[object, object] = {}
    for key_node, value_node in node.value:
        key = loader.construct_object(key_node, deep=deep)
        if key in mapping:
            raise ValueError("duplicate YAML key")
        mapping[key] = loader.construct_object(value_node, deep=deep)
    return mapping


_StrictSafeLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, _construct_mapping)


def _parse_skill_markdown(content: str) -> tuple[dict[str, object], int]:
    lines = content.splitlines(keepends=True)
    if not lines or lines[0].rstrip("\r\n") != "---":
        raise AIError(ErrorCode.OUTPUT_CONTRACT_INVALID)
    closing = next(
        (index for index, line in enumerate(lines[1:], 1) if line.rstrip("\r\n") == "---"),
        None,
    )
    if closing is None:
        raise AIError(ErrorCode.OUTPUT_CONTRACT_INVALID)
    raw = yaml.load("".join(lines[1:closing]), Loader=_StrictSafeLoader)
    if not isinstance(raw, Mapping):
        raise AIError(ErrorCode.OUTPUT_CONTRACT_INVALID)
    frontmatter = dict(raw)
    name = frontmatter.get("name")
    description = frontmatter.get("description")
    if not isinstance(name, str) or not 1 <= len(name) <= 64 or _SKILL_NAME.fullmatch(name) is None:
        raise AIError(ErrorCode.OUTPUT_CONTRACT_INVALID)
    if not isinstance(description, str) or not 1 <= len(description) <= 1024:
        raise AIError(ErrorCode.OUTPUT_CONTRACT_INVALID)
    for key, maximum in (("compatibility", 500),):
        if key in frontmatter and (
            not isinstance(frontmatter[key], str) or not 1 <= len(cast(str, frontmatter[key])) <= maximum
        ):
            raise AIError(ErrorCode.OUTPUT_CONTRACT_INVALID)
    for key in ("license", "allowed-tools"):
        if key in frontmatter and not isinstance(frontmatter[key], str):
            raise AIError(ErrorCode.OUTPUT_CONTRACT_INVALID)
    metadata_present = "metadata" in frontmatter
    metadata = frontmatter.get("metadata")
    if metadata_present and (
        not isinstance(metadata, Mapping)
        or any(not isinstance(key, str) or not isinstance(value, str) for key, value in metadata.items())
    ):
        raise AIError(ErrorCode.OUTPUT_CONTRACT_INVALID)
    revision_value = None if not metadata_present else cast(Mapping[str, str], metadata).get("linktools-revision")
    if revision_value is None:
        revision = 1
    elif (
        not isinstance(revision_value, str)
        or not revision_value.isdecimal()
        or int(revision_value) < 1
    ):
        raise AIError(ErrorCode.OUTPUT_CONTRACT_INVALID)
    else:
        revision = int(revision_value)
    return frontmatter, revision


__all__ = [
    "AgentSpecCodec",
    "MCPServerSpecCodec",
    "SkillMarkdownSpecAdapter",
    "SkillMarkdownSpecCodec",
    "SkillSpecCodec",
    "SpecCodec",
    "retarget_skill_markdown",
]
